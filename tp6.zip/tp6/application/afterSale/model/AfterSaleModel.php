<?php

namespace app\afterSale\model;

use think\Model;

class AfterSaleModel extends Model
{
    // 设置完整的数据表（包含前缀）
    protected $table = 'buaftersale';
}
