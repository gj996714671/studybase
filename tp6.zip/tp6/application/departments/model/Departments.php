<?php
namespace app\departments\model;

use think\Model;

class departments extends Model
{
    protected $table = 'budepartment';
}