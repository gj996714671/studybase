<?php

namespace app\feedback\model;

use think\Model;

class FeedbackModel extends Model
{
    // 设置完整的数据表（包含前缀）
    protected $table = 'bufeedback';
}
