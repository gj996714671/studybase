<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:79:"C:\wamp64\www\tp5\public/../application/customorder\view\update_order\form.html";i:1546585634;}*/ ?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Page Title</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../../../public/static/layui/css/layui.css">
  <script src="../../../public/static/js/jquery-3.3.1.js"></script>
  <script src="../../../public/static/layui/layui.js"></script>

  <script>

    layui.use('form', function () {
      var form = layui.form;
      //监听提交
      form.on('submit(formDemo)', function (data) {

        layer.confirm('确定提交修改?', { icon: 3, title: '提示' }, function (index) {
          $.ajax({
            url: '../../customOrder/Update_order/update.html',
            method: 'GET',
            data: data.field,
            dataType: 'JSON',
            success: function (res) {
              if (res == 1) {
                layer.msg("修改成功！！");
              }
              else
                layer.msg("未修改任何信息");
              // parent.closeIframe(res.msg);
            },
            error: function (data) {
              layer.msg("修改失败！服务器错误");
            }
          })
        });
        return false;
      });
    });
    //表单验证
    form.verify({
      price: [
        /^([1-9](\d+)?(\.\d{1,2})?$)|(^0$)|(^\d\.\d{1,2})+$/
        , '请输入正确单价'
      ]
    });
  </script>
</head>

<body>
  <!-- action="../../customOrder/Update_order/update.html" -->
  <form class="layui-form" id="test">

    <div class="layui-form-item">
      <label class="layui-form-label">订单编号</label>
      <div class="layui-input-block">
        <input type="text" name="order_num" disabled lay-verify="required" value="<?php echo $info['order_num']; ?>" autocomplete="off"
          class="layui-input">
      </div>
    </div>
    <input type="hidden" name="order_num" value="<?php echo $info['order_num']; ?>">
    <div class="layui-form-item">
      <label class="layui-form-label">顾客信息</label>
      <div class="layui-input-block">
        <P>姓名：<?php echo $info['name']; ?></P>
        <P>地址：<?php echo $info['address']; ?></P>
        <P>是否会员：<?php echo $info['level']; ?></P>
        <P>电话：<?php echo $info['phnone']; ?></P>
        <?php if(is_array($link) || $link instanceof \think\Collection || $link instanceof \think\Paginator): $i = 0; $__LIST__ = $link;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$link): $mod = ($i % 2 );++$i;?>
        <P>联系人<?php echo $i; ?>：<?php echo $link['name']; ?> 电话：<?php echo $link['phone']; ?></P>
        <?php endforeach; endif; else: echo "" ;endif; ?>
      </div>

    </div>
    <div class="layui-form-item">
      <label class="layui-form-label">商品信息</label>
      <div class="layui-input-block">
        <p>名称：<?php echo $info['product_name']; ?></p>
        <p>尺寸：<?php echo $info['product_size']; ?></p>
        <p>颜色：<?php echo $info['product_color']; ?> </p>
        <p>规格：<?php echo $info['product_model']; ?></p>
        <p>重量：<?php echo $info['product_weight']; ?></p>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">数量</label>
        <div class="layui-inline">
          <div class="layui-input-inline">
            <input type="number" name="amount" value="<?php echo $info['amount']; ?>" class="layui-input">
          </div>
          <label class="layui-form-label">单价</label>
          <div class="layui-input-inline">
            <input type="number" step="0.01" min="0.01" name="unPrice" value="<?php echo $info['unit_price']; ?>" class="layui-input"
              lay-verify="price">
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">选择渠道</label>
        <div class="layui-input-block">
          <select name="channel" lay-verify="required">
            <option value="<?php echo $info['order_channel']; ?>"><?php echo $info['order_channel']; ?></option>
            <option value="官方商城">官方商城</option>
            <option value="电商自营店">电商自营店</option>
            <option value="加盟实体店">加盟实体店</option>
            <option value="自营实体店">自营实体店</option>

          </select>
        </div>
      </div>

    </div>
    <div class="layui-form-item">
      <label class="layui-form-label">订单时间</label>
      <div class="layui-input-block">
        <input type="text" name="time" disabled value="<?php echo $info['order_time']; ?>" class="layui-input">
      </div>
    </div>




    <div class="layui-form-item">
      <label class="layui-form-label">销售人员</label>
      <div class="layui-input-block">
        <p>姓名：<?php echo $info['employee_name']; ?></p>
        <p>电话：<?php echo $info['phone']; ?></p>
        <p>部门：<?php echo $info['department_name']; ?></p>

      </div>
    </div>



    <div class="layui-form-item">
      <div class="layui-input-block">
        <button class="layui-btn" id="testbb" lay-submit lay-filter="formDemo">立即提交</button>
        <button type="reset" class="layui-btn layui-btn-primary">重置</button>
      </div>
    </div>


  </form>


</body>

</html>