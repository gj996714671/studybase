<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:95:"C:\wamp64\www\tp6\public/../application/customorder\view\manager_analysis\manager_analysis.html";i:1547106636;}*/ ?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>业绩审核</title>
    <script src="/tp6/public/static/js/jquery-3.3.1.js"></script>
    <script src="/tp6/public/static/layui/layui.js"></script>
    <link rel="stylesheet" href="/tp6/public/static/layui/css/layui.css">
</head>
<script type="text/html" id="maToolbar">



        <div class="layui-input-inline">
            <!-- <form class="layui-form"> -->
            <input type="text" name="Key" autocomplete="off" placeholder="请输入查询内容" class="layui-input layui-input-sm">
        <button class="layui-btn layui-btn-l" id="search" data-type="reload" lay-event="search">
            <i class="layui-icon" style="font-size: 20px; "></i> 搜索
        </button> 
    <!-- </form>    -->
        </div>

    
    
</script>

<body>
    <table id="manage" lay-filter="managerTable" lay-size="lg"></table>
    <script>
        var trArr = $(".layui-table-body.layui-table-main tr");
        //获取所有行元素
        var getAllRow = (function () {
            var arr = $(".layui-table-body.layui-table-main tr");
            var dataList = [];
            $.each(arr, function (index, trObj) {
                var tdArrObj = $(trObj).find('td');
                rowData = {};
                $.each(tdArrObj, function (index_1, tdObj) {
                    var td_field = $(tdObj).data("field");
                    rowData[td_field] = {};
                    rowData[td_field]["value"] = $($(tdObj).html()).html();
                    rowData[td_field]["cell"] = $(tdObj);
                    rowData[td_field]["row"] = $(trObj);
                })
                dataList.push(rowData);
            })//获取行元素结束
            return dataList;
        })
    </script>
    <script>
        layui.use('table', function () {
            var table = layui.table;
            var layer = layui.layer;
            var $ = layui.jquery;

            //第一个实例
            table.render({
                elem: '#manage' //指定原始 table 容器的选择器或 DOM，方法渲染方式必填
                , title: "业绩审核"
                , skin: 'line' //行边框风格
                , even: true //开启隔行背景
                , width: 1280
                , defaultToolbar: ['filter', 'print']
                , url: '/tp6/public/customOrder/managerAnalysis/info?order=desc&field=total' //数据接口
                , cols: [[ //表头
                        {field:'checkbox',title: 'checkbox',type:'checkbox'}//,LAY_CHECKED: true
                    , { field: 'num', title: '编号', type: 'numbers', width: 60, }
                    , { field: 'id', title: '员工编号', width: 142, sort: true }
                    , { field: 'name', title: '员工姓名', width: 142, sort: true ,edit: "text"}
                    , { field: 'type', title: '产品类别', width: 130, sort: true }
                    , { field: 'total', title: '销售总额', width: 130, sort: true ,totalRow: true}
                    , { field: 'order_time', title: '日期', width: 150, sort: true }
                ]]
                , page: true //开启分页
                , toolbar: '#maToolbar' //开启工具栏  若需要“列显示隐藏”、“导出”、“打印”等功能，则必须开启该参数 
                , totalRow: true //开启合计行
                , loading: true //是否显示加载条（默认：true）。如果设置 false，则在切换分页时，不会出现加载条。该参数只适用于 url 参数开启的方式
                , autoSort: false //默认 true，即直接由 table 组件在前端自动处理排序。若为 false，则需自主排序，通常由服务端直接返回排序好的数据。 
                , initSort: { //初始排序状态。用于在数据表格渲染完毕时，默认按某个字段排序。 
                    field: 'total' //排序字段，对应 cols 设定的各字段名
                    , type: 'desc' //排序方式  asc: 升序、desc: 降序、null: 默认排序
                }
                , response: {
                    statusName: 'code' //规定数据状态的字段名称，默认：code
                    , statusCode: 200 //规定成功的状态码，默认：0
                    , msgName: 'msg' //规定状态信息的字段名称，默认：msg
                    , countName: 'count' //规定数据总数的字段名称，默认：count
                    , dataName: 'data' //规定数据列表的字段名称，默认：data
                    , sortField: 'sortField'
                    , sortType: 'sortType'
                    , page: 'page'
                    , size: 'size'
                }
                , parseData: function (res) { //res 即为原始返回的数据
                    var sortType = res.sortType;
                    return {
                        "code": res.code, //解析接口状态
                        "msg": res.msg, //解析提示文本
                        "count": res.count, //解析数据长度
                        "data": res.data, //解析数据列表
                        "sortField": res.sortField,
                        "sortType": res.sortType,
                        "page": res.page,
                        "size": res.size
                    };
                }//parseData 结束
                // 表格渲染完成之后的回调
                , done: function (res, curr, count) {
                    $(".layui-table th").css("font-weight", "bold");// 设定表格标题字体加粗
                    // 对相关数据进行判断处理
                    var allRow = getAllRow();
                    $.each(allRow, function (index, obj) {

                        if (res.sortField == 'total' && res.sortType == 'desc') {
                            //当页面尺寸小于等于10
                            if (res.size <= 10) {
                                if (res.page == 1) {
                                    if (index < 3) {
                                        obj['total'].row.css("color", "#FF0000");
                                    }
                                    else if (index <= 10) {
                                        obj['total'].row.css("color", "#00FFFF");
                                    }
                                } else
                                    if (res.page == 2) {
                                        if (index <= 10) {
                                            obj['total'].row.css("color", "#FFA500");
                                        }
                                    }
                                    else {
                                        obj['total'].row.css("color", "#ff1493");
                                    }
                            }
                            //页面大小大于10,默认其次是20
                            else if (res.size > 10) {
                                if (res.page == 1) {
                                    if (index < 3) {
                                        obj['total'].row.css("color", "#FF0000");
                                    } else if (index < 10) {
                                        obj['total'].row.css("color", "#00FFFF");
                                    } else if (index < 20) {
                                        obj['total'].row.css("color", "#FFA500");
                                    } else {
                                        obj['total'].row.css("color", "#ff1493");
                                    }
                                }//20之后全部浅粉色
                                else {
                                    obj['total'].row.css("color", "#ff1493");
                                }
                            }
                        }
                    })
                }//done 结束


            });//table render 结束
            // //监听排序事件 
            table.on('sort(managerTable)', function (sortobj) { //注：tool是工具条事件名，manager是table原始容器的属性 lay-filter="对应的值"
                //尽管我们的 table 自带排序功能，但并没有请求服务端。
                //有些时候，你可能需要根据当前排序的字段，重新向服务端发送请求，从而实现服务端排序，如：
                table.reload('manage', {
                    initSort: sortobj //记录初始排序，如果不设的话，将无法标记表头的排序状态。
                    , where: { //请求参数（注意：这里面的参数可任意定义，并非下面固定的格式）
                        field: sortobj.field //排序字段
                        , order: sortobj.type //排序方式     
                    }
                });//reload 结束
            });//监听排序结束

            //监听搜索事件
            table.on('toolbar(managerTable)', function (obj) {
                var checkStatus = table.checkStatus(obj.config.id);
                switch (obj.event) {
                    case 'search':
                        layer.msg('搜索');
                        break;
                    case 'delete':
                        layer.msg('删除');
                        break;
                    case 'update':
                        layer.msg('编辑');
                        break;
                };
            });

            //监听单元格编辑
            table.on('edit(managerTable)', function (obj) { //注：edit是固定事件名，manager是table原始容器的属性 lay-filter="对应的值"
                console.log(obj.value); //得到修改后的值
                console.log(obj.field); //当前编辑的字段名
                console.log(obj.data); //所在行的所有相关数据  
            });

            //监听行单击事件
            table.on('row(managerTable)', function (obj) {
                console.log(obj.tr) //得到当前行元素对象
                console.log(obj.data) //得到当前行数据
                //obj.del(); //删除当前行
                //obj.update(fields) //修改当前行数据
            });//监听行单击事件结束

            //监听行双击事件
            table.on('rowDouble(managerTable)', function (obj) {
                //obj 同上
                console.log("完成双击666") //得到当前行数据
            });//监听行单击事件结束
        });//layui 结束

    </script>

</body>

</html>