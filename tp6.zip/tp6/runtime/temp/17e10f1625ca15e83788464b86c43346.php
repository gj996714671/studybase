<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:72:"C:\wamp64\www\tp5\public/../application/customorder\view\index\test.html";i:1546499865;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <table class="table table-striped table-hover">
        <thead>
            <tr>
                <th>\</th>
                <th id="stu_rollno">订单编号</th>
                <th id="customerId">顾客编号</th>
                <th id="major_name">创建时间</th>
                <th id="course_name">渠道</th>
                <th id="tea_name">数量</th>
                <th id="mark">单价</th>
                <th id="mark">总额</th>
                <th id="mark">销售员编号</th>
            </tr>
        </thead>
    
        <?php if(is_array($cusTomOrder) || $cusTomOrder instanceof \think\Collection || $cusTomOrder instanceof \think\Paginator): $i = 0; $__LIST__ = $cusTomOrder;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$order): $mod = ($i % 2 );++$i;?>
        <tr>
            <td><?php echo $i; ?></td>
            <td><?php echo $order['order_num']; ?></td>
            <td><?php echo $order['custom_num']; ?></td>
            <td><?php echo $order['order_time']; ?></td>
            <td><?php echo $order['order_channel']; ?></td>
            <td><?php echo $order['amount']; ?></td>
            <td><?php echo $order['unit_price']; ?></td>
            <td><?php echo $order['unit_price']*$order['amount']; ?></td>
            <td><?php echo $order['saler_num']; ?></td>
        </tr>
        <?php endforeach; endif; else: echo "" ;endif; ?>
    </table>
</body>
</html>