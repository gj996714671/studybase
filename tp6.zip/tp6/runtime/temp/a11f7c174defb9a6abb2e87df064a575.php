<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:73:"C:\wamp64\www\tp5\public/../application/customorder\view\index\index.html";i:1546585634;}*/ ?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>订单管理</title>
    <style>
        body{
	color: #333;
	font: 16px Verdana, "Helvetica Neue", helvetica, Arial, 'Microsoft YaHei', sans-serif;
	margin: 0px;
	padding: 20px;
}

a{
	color: #868686;
	cursor: pointer;
}
a:hover{
	text-decoration: underline;
}
h2{
	color: #4288ce;
	font-weight: 400;
	padding: 6px 0;
	margin: 6px 0 0;
	font-size: 28px;
	border-bottom: 1px solid #eee;
}
div{
margin:8px;
}
.info{
	padding: 12px 0;
	border-bottom: 1px solid #eee;
}

.copyright{
	margin-top: 24px;
	padding: 12px 0;
  border-top: 1px solid #eee;
}
</style>
    <!-- <script src="https://cdn.staticfile.org/jquery/1.10.2/jquery.min.js"></script> -->
    <script src="../../public/static/js/jquery-3.3.1.js"></script>
    <script src="../../public/static/layer/layer.js"></script>
    <script>
        $(document).ready(function () {
            $('.submit').on('click', function () {
                var id = $(this).attr("id");
                var cusTomerId = $(this).attr("customerId");
                layer.open({
                    type: 2,
                    title: '修改订单',
                    maxmin: true,
                    shadeClose: true, //点击遮罩关闭层
                    area: ['800px', '650px'],
                    //   content: ['../../public/customOrder/Update_order/form?id='+id,'no']
                    content: '../../public/customOrder/Update_order/form?id=' + id
                });
            });
            $('#customer').on('click', function () {
                layer.open({
                    type: 2,
                    title: '创建新客户',
                    maxmin: true,
                    shadeClose: true, //点击遮罩关闭层
                    area: ['480px', '500px'],
                    //禁用滚动条
                    content: ['../../public/customer/index/index', 'no']
                    //   content: '../../public/customOrder/Update_order/form?id='+id
                });
            });
            //校验文件是否为空
            $("#excel").bind("submit", function () {
                var file = $("#file").val();
                if (file == "") {
                    alert("请选择导入文件！！！");
                    return false;
                }
            });
        });
    </script>
</head>

<body>
    <h2>订单列表</h2>

    <a href='../../public/customOrder/index/excelPrint'><button id="excel">导出Excel</button></a>
    <a href='../../public/customOrder/index/getPdf'><button id="pdf">导出PDF</button></a>
    <a href="../../顾客订单导入模板.xlsx"><button value="下载模板">下载导入模板</button></a>

    <button id="customer">新建客户</button>
    <div>
        <!-- action="<?php echo url('customOrder/import_from_excel/import'); ?>" -->
        <form id="excel" method="post" action="<?php echo url('customOrder/import_from_excel/import'); ?>" class="form-signin"
            enctype="multipart/form-data">
            <input id="file" name="excel" type="file" class="form-control">
            <button class="btn btn-lg btn-primary btn-block" id="btton">导入订单</button>
        </form>
    </div>
    <table class="table table-striped table-hover">
        <thead>
            <tr>
                <th>\</th>
                <th id="stu_rollno">订单编号</th>
                <th id="customerId">顾客编号</th>
                <th id="product_id">产品名称</th>
                <th id="tea_name">数量</th>
                <th id="mark">单价</th>
                <th id="mark">总额</th>
                <th id="mark">销售员编号</th>
                <th id="major_name">创建时间</th>
                <th id="course_name">渠道</th>
                <th id="type">操作</th>
                <!-- <th id="type">活动类型</th> -->
            </tr>
        </thead>

        <?php if(is_array($cusTomOrder) || $cusTomOrder instanceof \think\Collection || $cusTomOrder instanceof \think\Paginator): $i = 0; $__LIST__ = $cusTomOrder;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$order): $mod = ($i % 2 );++$i;?>
        <tr>
            <td>
                <?php echo ( $_GET['page']?($_GET['page']*10-10+$i):$i  ); ?>
            </td>
            <td><?php echo $order['order_num']; ?></td>
            <td><?php echo $order['custom_num']; ?></td>
            <td><?php echo $order['product_name']; ?></td>

            <td><?php echo $order['amount']; ?></td>
            <td><?php echo $order['unit_price']; ?></td>
            <td>
                <?php echo $order['unit_price']*$order['amount']; ?>
            </td>
            <td><?php echo $order['saler_num']; ?></td>

            <td><?php echo $order['order_time']; ?></td>
            <td><?php echo $order['order_channel']; ?></td>
            <!-- <td><?php echo $order['activity']; ?></td> -->
            <td><button class="submit" id=<?php echo $order['order_num']; ?>">修改</button></td>
        </tr>
        <?php endforeach; endif; else: echo "" ;endif; ?>
    </table>
    <?php echo $cusTomOrder->render(); ?>
    <div class="copyright">
        <a title="官方网站" href="http://localhost/tp5/public/customOrder/index?page=1">XX家电</a>
        <span>V5</span>
        <span>{ 十年磨一剑-为API开发设计的高性能框架 }</span>
    </div>
</body>

</html>