<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:67:"C:\wamp64\www\tp6\public/../application/staff\view\staff\staff.html";i:1546993734;}*/ ?>
<!DOCTYPE html>
<html>
<head> 
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Document</title>
        <link href="https://cdn.bootcss.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdn.bootcss.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
        <script src="https://cdn.bootcss.com/jquery/2.2.4/jquery.min.js"></script>
        <script src="https://cdn.bootcss.com/bootstrap/4.1.1/js/bootstrap.bundle.min.js"></script>
         <link rel="stylesheet" href="theme.css" type="text/css"> 
</head>
<body>
    <div class="container" style=" height:452px;">
        <div class="row">
            <div class="offset-md-1 col-md-10">
                <br>
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th id="stu_rollno">员工编号</th>
                            <th id="customerId">姓名</th>
                            <th id="product_id">角色</th>
                            <th id="tea_name">角色描述</th>
                        </tr>
                    </thead>                
                        <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$staff): $mod = ($i % 2 );++$i;?>
                        <tr>
                            <td><?php echo $staff['employee_id']; ?></td>
                            <td><?php echo $staff['employee_name']; ?></td>
                            <td><?php echo $staff['role_name']; ?></td>             
                            <td><?php echo $staff['role_desc']; ?></td>
                        </tr>
                        <?php endforeach; endif; else: echo "" ;endif; ?>
                    </table>
                    <?php echo $list->render(); ?>
            </div>
        </div>
    </div>
</body>
</html>

