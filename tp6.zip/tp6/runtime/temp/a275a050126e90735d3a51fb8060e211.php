<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:71:"C:\wamp64\www\tp6\public/../application/aftersale\view\Index\index.html";i:1546993733;}*/ ?>
<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>订单管理</title>
<script src="/tp6/public/static/js/jquery-3.3.1.js"></script>
<script src="/tp6/public/static/layer/layer.js"></script>
<script>  
       $(document).ready(function(){
        $('.submit').on('click', function(){
        var id =$(this).attr("id");
        layer.open({
          type: 2,
          title: '修改订单',
          maxmin: true,
          shadeClose: true, //点击遮罩关闭层
          area : ['1000px' , '420px'],
          content: 'http://localhost/tp6/public/afterSale/UpdateAftersale/form?id='+id
            });
        });
        $('.submitfeedback').on('click', function(){
        var id =$(this).attr("id");
        layer.open({
          type: 2,
          title: '修改订单',
          maxmin: true,
          shadeClose: true, //点击遮罩关闭层
          area : ['1000px' , '420px'],
          content: 'http://localhost/tp6/public/feedback/Feedback/insertfromSV?id='+id
            });
        });
        return false;
       });
    </script>
    <link href="https://cdn.bootcss.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.bootcss.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <script src="https://cdn.bootcss.com/jquery/2.2.4/jquery.min.js"></script>
    <script src="https://cdn.bootcss.com/bootstrap/4.1.1/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="theme.css" type="text/css">
    <link rel="stylesheet" href="/tp6/public/static/css/aftersale.css" type="text/css">   
</head>

<body>
    <br>
    <br>
    <br>
<table class="table table-striped table-hover">
    <thead>
        <tr>
            
            <th id="aftersale_id">售后编号</th>
            <th id="order_num">订单编号</th>
            <th id="question_type">问题类型</th>
            <th id="employee_id">售后人员</th>
            <th id="processing_date">受理日期</th>
            <th id="state">受理状态</th>
            <th id="question">问题详情</th>
            <th id="alter">修改</th>
            <th id='feedback'>售后反馈</th>
        </tr>
    </thead>

    <?php if(is_array($aftersaleInfo) || $aftersaleInfo instanceof \think\Collection || $aftersaleInfo instanceof \think\Paginator): $i = 0; $__LIST__ = $aftersaleInfo;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$Info): $mod = ($i % 2 );++$i;?>
    <tr>
        <td><?php echo $Info['aftersale_roll']; ?></td>
        <td><?php echo $Info['order_num']; ?></td>
        <td><?php echo $Info['question_type']; ?></td>
        <td><?php echo $Info['employee_id']; ?></td>
        <td><?php echo $Info['processing_date']; ?></td>
        <td><?php echo $Info['state']; ?></td>
        <td><?php echo $Info['question']; ?></td>
        <?php
        if($Info['state']=='办结'){
            echo "<td><button class='submit' id=".$Info['aftersale_roll'].">修改</button></td>".
            "<td><button class='submitfeedback' disabled id=".$Info['aftersale_roll'].">售后反馈</button></td>";;
        }else{
            echo "<td><button class='submit' id=".$Info['aftersale_roll'].">修改</button></td>".
            "<td><button class='submitfeedback' id=".$Info['aftersale_roll'].">售后反馈</button></td>";
        }
        ?>
        
    </tr>
    <?php endforeach; endif; else: echo "" ;endif; ?>
</table>
<?php echo $aftersaleInfo->render(); ?>
</body>
</html>
