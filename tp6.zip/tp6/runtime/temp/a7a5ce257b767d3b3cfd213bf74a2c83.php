<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:67:"C:\wamp64\www\tp5\public/../application/login\view\index\admin.html";i:1546586224;}*/ ?>
<!DOCTYPE html>

        <style> 

                @font-face
                {
                    font-family: myfont;
                    src:url('/tp5/public/static/font/Login.ttf');
                }
                body
                {
                    background:url('/tp5/public/static/images/back1.png') no-repeat;
                    background-position-x: 45%;
                    background-position-y: 47%;
                    background-size: 100% 64%;
                }
                #bodys
                {
                    height:452px;
                }
               
               #but
               {
                   width: 100%;
                   text-align: center;
                   
               }
               .bt 
               {
                    display: inline-block;
                    border-radius: 6px;
                    background-color:rgba(207, 193, 193,0);
                    border: none;
                    text-align: center;
                    font-size: 28px;
                    padding: 10px;
                    width: 40%;
                    height: 80%;
                    transition: all 0.5s;
                    cursor: pointer;
                    margin: 2.5%;
                    outline: none;
              
                }
                .bt:hover
                {
                    background-color:rgba(81, 185, 233, 0.5);
                    font-style: italic;
                }
                  
                .bt span 
                {
                    cursor: pointer;
                    display: inline-block;
                    position: relative;
                    transition: 0.5s;
                    font-size: 30px;
                    color:white;
                    font-family: myfont;
                }
        
                .bt span:after 
                {
                    content: '»';
                    position: absolute;
                    opacity: 0;
                    top: 0;
                    right: -20px;
                    transition: 0.5s;
                    color: black;

                }
        
                .bt:hover span 
                {
                    padding-right: 25px;
                    color: black;
                }
        
                .bt:hover span:after 
                {
                    opacity: 1;
                    right: 0;
                }
        
                .bt:active:after 
                {
                    padding: 0;
                    margin: 0;
                    opacity: 1;
                    transition: 0s
                }
                .bt1
               {
                    display: inline-block;
                    border-radius: 6px;
                    background-color:rgba(207, 193, 193,0);
                    border: none;
                    text-align: center;
                    font-size: 28px;
                    padding: 10px;
                    width: 25%;
                    height: 40%;
                    transition: all 0.5s;
                    cursor: pointer;
                    margin: 2.5%;
              
                }
                .bt1:hover
                {
                    background-color:rgba(81, 185, 233, 0.5);
                    font-style: italic;
                }
                  
                .bt1 span 
                {
                    cursor: pointer;
                    display: inline-block;
                    position: relative;
                    transition: 0.5s;
                    font-size: 30px;
                    color:white;
                    font-family: myfont;
                }
        
                .bt1 span:after 
                {
                    content: '»';
                    position: absolute;
                    opacity: 0;
                    top: 0;
                    right: -20px;
                    transition: 0.5s;
                    color: black;

                }
        
                .bt1:hover span 
                {
                    padding-right: 25px;
                    color: black;
                }
        
                .bt1:hover span:after 
                {
                    opacity: 1;
                    right: 0;
                }
        
                .bt1:active:after 
                {
                    padding: 0;
                    margin: 0;
                    opacity: 1;
                    transition: 0s
                }
                #loginout
                {
                    margin-right: -10%;

                }
               </style>
<head> 
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Document</title>
        <link href="https://cdn.bootcss.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdn.bootcss.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
        <script src="https://cdn.bootcss.com/bootstrap/4.1.1/js/bootstrap.bundle.min.js"></script>
        <link rel="stylesheet" href="theme.css" type="text/css">   
</head>
<html>

<body>
    <nav class="navbar navbar-expand-md  navbar-dark"  style="background:#004B97;">
        <div class="container">
            <a class="navbar-brand" href="#">
                <img class="img-fluid d-block float-left" src="/tp5/public/static/images/logo.png"> 
            </a>
            <?php
            echo " <h1  style='font-family: myfont;font-size:18px;margin-right:-50%;'>你好 &nbsp ".cookie('user_name').'<br>登陆时间是 &nbsp'.cookie('rec_time')." </h1> ";  
            ?>            
            <a id="loginout" class="btn navbar-btn ml-2 text-white btn-secondary" href="<?php echo url('index/loginOut'); ?>">
            <i class="fa d-inline fa-lg fa-sign-in"></i>
            登出
            </a>
            
            
        </div>
    </nav>

    <div id="bodys" class="container">
        <div class="row">
            <div class="offset-md-1 col-md-10">
                    <button class="bt" style="vertical-align:middle" onclick="window.location.href='../../academy/Academy/form.html'"><span>Check Academy</span></button>
                    <button class="bt" style="vertical-align:middle" onclick="window.location.href='../../major/Major/form.html'"><span>Check Major</span></button><br>
                    <button class="bt1" style="vertical-align:middle" onclick="window.location.href='../../course/Course/form.html'"><span>Check Course</span></button>
                    <button class="bt1" style="vertical-align:middle" onclick="window.location.href='../../teacher/Teacher/form.html'"><span>Check Teacher</span></button>
                    <button class="bt1" style="vertical-align:middle" onclick="window.location.href='../../student/Student/form.html'"><span>Check Student</span></button>
            </div>
        </div>
    </div>

        <div class="py-5 text-white" style="background:#004B97;">
            <div class="container" style="background: #004B97;">
                <div class="row">
                  <div class="col-md-9" >
                    <p>© Copyright 2018 University Management - All rights reserved.</p>
                  </div>
                  <div class="col-4 col-md-1 align-self-center">
                    <a href="https://weibo.com/u/5726029829?nick=%E9%9D%92%E5%B2%9B%E5%A4%A7%E5%AD%A6" target="_blank">
                      <i class="fa fa-fw fa-3x text-white fa-weibo"></i>
                    </a>
                  </div>
                  <div class="col-4 col-md-1 align-self-center">
                    <a href="https://wechat.com" target="_blank">
                      <i class="fa fa-fw fa-3x text-white fa-weixin"></i>
                    </a>
                  </div>
                  <div class="col-4 col-md-1 align-self-center">
                    <a href="https://www.weibo.com" target="_blank">
                      <i class="fa fa-fw text-white fa-3x fa-tencent-weibo"></i>
                    </a>
                </div>
            </div>
        </div>
    </div> 
   
</body>

</html>


