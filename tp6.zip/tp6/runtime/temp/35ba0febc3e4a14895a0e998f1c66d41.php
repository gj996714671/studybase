<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:67:"C:\wamp64\www\tp6\public/../application/login\view\index\login.html";i:1546993566;}*/ ?>
<!DOCTYPE html>
<?php 
session_start(); //启用会话变量    
?>
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login</title>
    <link href="https://cdn.bootcss.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.bootcss.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <script src="https://cdn.bootcss.com/bootstrap/4.1.1/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="theme.css" type="text/css">
    <link rel="stylesheet" href="/tp6/public/static/css/login.css" type="text/css">   
  </head>
  
<html>

<body>
    
  <div class="py-5 text-center">
    <div  id="forms" class="container">
      <div class="row">
        <div id="forms1" class="mx-auto col-md-6 col-10 p-5">
          <form action="<?php echo url('index/dologin'); ?>" method="post">
              <img id="images" src="/tp6/public/static/images/logo.png">
              <fieldset class="mx-auto col-md-12 col-5 p-5">
              <legend id="fonts" class="mb-4 text-light">(Log in)</legend>
              <div class="form-group"> <input  type="text" class="form-control" name="userid" placeholder="Enter email" id="form9"> </div>
              <div class="form-group mb-3"> <input type="password" class="form-control" name="password" placeholder="Password" id="form10"> 
                <small class="form-text text-muted text-right"><a id="fyp" href="#"> Forget your password?</a></small> 
              </div> 
              <button id="btn" type="submit" class="btn btn-primary">Submit</button>
            </fieldset>
          </form>
        </div>
      </div>
    </div>
  </div>
  

  <script src="https://code.jquery.com/jquery-3.2.1.min.js" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" crossorigin="anonymous" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  
</body>

</html>
