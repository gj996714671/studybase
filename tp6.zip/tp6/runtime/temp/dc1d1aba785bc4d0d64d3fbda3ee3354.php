<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:68:"C:\wamp64\www\tp6\public/../application/chart\view\chart\charta.html";i:1546993733;}*/ ?>
<!DOCTYPE html>
<html>
    <style>
        @font-face
                {
                    font-family: myfont;
                    src:url('/tp6/public/static/font/GunfighterAcademy-Regular.ttf');
                }
    
    </style>
<head> 
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Document</title>
        <link href="https://cdn.bootcss.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdn.bootcss.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
        <script src="https://cdn.bootcss.com/jquery/2.2.4/jquery.min.js"></script>
        <script src="https://cdn.bootcss.com/bootstrap/4.1.1/js/bootstrap.bundle.min.js"></script>
         <link rel="stylesheet" href="theme.css" type="text/css"> 

         <link rel="stylesheet" href="/tp6/public/static/styles/kendo.common.min.css" />
         <link rel="stylesheet" href="/tp6/public/static/styles/kendo.default.min.css" />
         <link rel="stylesheet" href="/tp6/public/static/styles/kendo.default.mobile.min.css" />

         <script src="/tp6/public/static/js/jquery.min.js"></script>
         <script src="/tp6/public/static/js/kendo.all.min.js"></script>
</head>
<body>
    
    <div  class="container" style=" height:452px;">
        <hr>
        <br>
        <br>
        <div class="row"><h2>产品销售额柱状图</h2></div>
        <hr>
        <div style="background-color: transparent;box-shadow:0px 0px 8px 5px #ccc;">
            <div class="row offset-md-1 col-md-10">
                <div class="offset-md-1 col-md-10"></div>
                <br>
                <form action="<?php echo url('Chart/showcharta'); ?>" method="post">
                    <table>
                        <tr>
                            <td><input  type="date" class="form-control" name="starttime" id=""></td>
                            <td><input  type="date" class="form-control" name="endtime" id=""></td>
                            <td><button id="btn" type="submit" class="btn btn-primary">Submit</button></td>
                        </tr>
                    </table>   
                </form>
                <br>
                <br>

            </div>
            <div class="demo-section k-content wide">
                <div id="chart"></div>
            </div>
        </div>

        <hr>
        <br>
        <br>
        <div class="row"><h2>最受欢迎产品（类别）分布图</h2></div>
        <hr>

        <div class="row" style="background-color: transparent;box-shadow:0px 0px 8px 5px #ccc;">
            
            <div class="offset-md-1 col-md-5">
                <div class="demo-section k-content wide">
                    <div id="pie1"></div>
                </div>
            </div>
            <div class=" col-md-5">
                <div class="demo-section k-content wide">
                    <div id="pie2"></div>
                </div>
            </div>
            
        </div>

        <hr>
        <hr>


        <div class="row">
            <div class="col-md-5" style="background-color: transparent;box-shadow:0px 0px 8px 5px #ccc;">
                <br>
                <br>
                <h2>产品购买途径统计表</h2>
                <br>
                <!-- <form action="<?php echo url('Role/role'); ?>" method="post">
                    <table>
                        <tr>
                            <td><input  type="text" class="form-control" name="employeeid" placeholder="Enter employeeID" id=""></td>
                            <td><button id="btn" type="submit" class="btn btn-primary">Submit</button></td>
                        </tr>
                    </table>   
                </form> -->

                <table class="table table-striped table-hover">
                    <thead>
                    <tr>
                        <td>产品名称</td>
                        <td>途径购买数量</td>
                        <td>购买途径销售金额</td>
                        
                    </tr>
                    </thead>
                    <tbody>
                    <?php if(is_array($list2) || $list2 instanceof \think\Collection || $list2 instanceof \think\Paginator): $i = 0; $__LIST__ = $list2;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                    <tr>
                        <td><?php echo $vo['name']; ?></td>
                        <td><?php echo $vo['count']; ?></td>
                        <td><?php echo $vo['sum']; ?></td>
                    </tr>
                    <?php endforeach; endif; else: echo "" ;endif; ?>  
                    </tbody>
                    
                </table>
    
            </div>


            <div class="offset-md-2 col-md-5" style="background-color: transparent;box-shadow:0px 0px 8px 5px #ccc;">
                <br>
                <br>
                <h2>质量问题统计表</h2>
                <br>
                <table class="table table-striped table-hover">
                    <thead>
                    <tr>
                        <td>产品名称</td>
                        <td>问题反馈数量</td>
                        
                    </tr>
                    </thead>
                    <tbody>
                    <?php if(is_array($list1) || $list1 instanceof \think\Collection || $list1 instanceof \think\Paginator): $i = 0; $__LIST__ = $list1;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                    <tr>
                        <td><?php echo $vo['name']; ?></td>
                        <td><?php echo $vo['count']; ?></td>
                    </tr>
                    <?php endforeach; endif; else: echo "" ;endif; ?>  
                    </tbody>
                    
                </table>
        
            </div>
        </div>
        <br>
        <hr>
        <br>
        

    </div> 
    <script>
        function createChart() {
            var avgmax = <?php echo $avgmax; ?>;
            var pname = <?php echo $pname; ?>;
            var pie1 = <?php echo $pie1; ?>;
            var pie2 = <?php echo $pie2; ?>;
            $("#chart").kendoChart({
                title: {
                    text: "产品类别销售额统计"
                },
                legend: {
                    position: "bottom"
                },
                series: avgmax,
                categoryAxis: {
                    categories: pname
                },
               
            });



            $("#pie1").kendoChart({
                title: {
                    position: "bottom",
                    text: "最受欢迎产品类别分布"
                },
                legend: {
                    visible: false
                },
                chartArea: {
                    background: ""
                },
                seriesDefaults: {
                    labels: {
                        visible: true,
                        background: "transparent",
                        template: "#= category #: \n #= value#%"
                    }
                },
                series: [{
                    type: "pie",
                    startAngle: 150,
                    data: pie1
                }],
                tooltip: {
                    visible: true,
                    format: "{0}%"
                }
            });


            $("#pie2").kendoChart({
                title: {
                    position: "bottom",
                    text: "最受欢迎产品分布"
                },
                legend: {
                    visible: false
                },
                chartArea: {
                    background: ""
                },
                seriesDefaults: {
                    labels: {
                        visible: true,
                        background: "transparent",
                        template: "#= category #: \n #= value#%"
                    }
                },
                series: [{
                    type: "pie",
                    startAngle: 150,
                    data: pie2
                }],
                tooltip: {
                    visible: true,
                    format: "{0}%"
                }
            });

        }

            

        $(document).ready(createChart);
        $(document).bind("kendo:skinChange", createChart);
    </script> 
</body>  
</html>