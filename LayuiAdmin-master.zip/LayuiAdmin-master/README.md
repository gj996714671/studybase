# LayuiAdmin
基本于layui-v2.4.5版的admin后台模版(iframe版)

根据静态页文件所对应的url,通过HttpURLConnection，访问请求后，生成本地文件，该项目仅限于学习使用。
